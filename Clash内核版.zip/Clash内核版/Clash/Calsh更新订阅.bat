
@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

set "filename=config.yaml"
set "filepath=%USERPROFILE%\.config\clash\%filename%"
del "%filepath%" 2>nul
chcp 65001 > nul

curl -v -s --limit-rate 2M  "https://zhanggithubcom.github.io/subscription.github.io/jcbb-new.yaml" -o "%filepath%"


echo Calsh更新订阅完成！


call "重启.bat"

echo 请按下任意键退出本窗口...
pause > nul

rem 退出脚本
exit /b

