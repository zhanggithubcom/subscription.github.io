Set objShell = CreateObject("WScript.Shell")
objShell.Run "Clash.exe", 0, False