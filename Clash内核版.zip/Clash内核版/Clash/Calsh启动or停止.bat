@echo off
tasklist /FI "IMAGENAME eq Clash.exe" | find /i "Clash.exe"
if "%ERRORLEVEL%"=="0" (
	call "Calsh停止.bat"	
) else (

	call "Calsh启动.bat"	
)
echo 请按下任意键退出本窗口...
pause > nul

rem 退出脚本
exit /b